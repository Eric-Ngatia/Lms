# Flashcards - SQS SNS EventBridge e Step Functions

1. **Qual e o foco deste modulo?**  
   Decidir quando SQS SNS EventBridge e Step Functions muda a arquitetura recomendada.

2. **Qual e o primeiro passo em cenarios longos?**  
   Identificar o requisito dominante.

3. **O que elimina alternativas?**  
   Limites, risco operacional, custo recorrente, seguranca ou indisponibilidade.

4. **Quando evitar solucao sofisticada?**  
   Quando ela nao responde a uma restricao explicita.

5. **Como validar a decisao?**  
   Conferir documentacao oficial, quotas e comportamento de falha.

---

Continue seus estudos na CloudStudy:

[https://cloudstudy.com.br](https://cloudstudy.com.br)
